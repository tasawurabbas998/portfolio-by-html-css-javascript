console.log("Script Running.....")
document.querySelector('.cross').Style.display= 'none';
document.querySelector('.ham').addEventListener("click", ()=>{
document.querySelector('.sidebar').classList.toggle('sidebarGo')
});
